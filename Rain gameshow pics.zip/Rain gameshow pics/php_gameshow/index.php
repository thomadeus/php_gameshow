<?php
include 'util.php';
?>
<!DOCTYPE html>
<html>

<head>
    <title>Homepage</title>
    <link href="./game.css" type="text/css" rel="stylesheet" />
</head>

<body class="index">
   
    <h1>Are You Smarter Than A Fifth Grader</h1>
    <div><a href="signup.php">New Player<br></a></div>
    <div><a href="login.php">Returning<br></a></div>
    <div><a href="leaderboards.php">Leaderboards<br></a></div>

    <br>
    <p>Results and page (C) Copyright blabla Inc.</p>
    <br>
</body>

</html>