<html>
<head> </head>
<title> </title>

<link rel="stylesheet" href="QAboard.css">
<style>
body {
  background-image: url("skoolboard3.png");
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
</style>

<body>

<h1>5th Grade History Question</h1>
<div class="main">
<b style="color:deeppink;">For 250 points:</b>
<h3>What is the imaginary horizontal line that marks locations?</h3>
<ol>
	<div class="button1"> Latitude</div>
	<br>
	<div class="button2"> Longitude</div>
	<br>
	<div class="button3"> Quadrant</div>
	<br>
	<div class="button4"> Horizon</div>
</ol>
</div>




</body>
</html>